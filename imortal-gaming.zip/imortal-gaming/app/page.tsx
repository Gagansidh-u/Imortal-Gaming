import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <section className="flex-grow flex items-center justify-center relative overflow-hidden py-20">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-900 to-blue-900 opacity-75"></div>
          <div 
            className="absolute inset-0 bg-[url('/3d-background.svg')] bg-cover bg-center animate-pulse-slow"
            style={{
              animation: 'pulse 5s cubic-bezier(0.4, 0, 0.6, 1) infinite, float 10s ease-in-out infinite',
              transform: 'perspective(1000px) rotateX(5deg) rotateY(5deg)',
            }}
          ></div>
        </div>
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-white shadow-text">Welcome to Imortal Gaming</h1>
          <p className="text-xl md:text-2xl mb-8 text-white shadow-text">Experience the future of online gaming</p>
          <div className="space-x-4">
            <Button asChild className="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-full transition-colors">
              <Link href="/games">Explore Games</Link>
            </Button>
            <Button asChild variant="outline" className="bg-transparent hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-full transition-colors border-2 border-white hover:border-transparent">
              <Link href="/tournaments">Join Tournaments</Link>
            </Button>
            <Button asChild variant="outline" className="bg-transparent hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-full transition-colors border-2 border-white hover:border-transparent">
              <Link href="/admin">Admin Panel</Link>
            </Button>
          </div>
          <p className="mt-8 text-sm text-gray-400">This site is developed by Gagan Sidhu</p>
        </div>
      </section>
    </div>
  )
}

