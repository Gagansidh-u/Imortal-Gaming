import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-gray-900 border-t border-gray-800 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About Imortal</h3>
            <ul className="space-y-2">
              <li><Link href="/about" className="hover:text-purple-400 transition-colors">About Us</Link></li>
              <li><Link href="/careers" className="hover:text-purple-400 transition-colors">Careers</Link></li>
              <li><Link href="/press" className="hover:text-purple-400 transition-colors">Press</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><Link href="/help" className="hover:text-purple-400 transition-colors">Help Center</Link></li>
              <li><Link href="/safety" className="hover:text-purple-400 transition-colors">Safety Center</Link></li>
              <li><Link href="/community" className="hover:text-purple-400 transition-colors">Community Guidelines</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li><Link href="/terms" className="hover:text-purple-400 transition-colors">Terms of Service</Link></li>
              <li><Link href="/privacy" className="hover:text-purple-400 transition-colors">Privacy Policy</Link></li>
              <li><Link href="/cookies" className="hover:text-purple-400 transition-colors">Cookie Policy</Link></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Follow Us</h3>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-purple-400 transition-colors">Twitter</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">Facebook</a></li>
              <li><a href="#" className="hover:text-purple-400 transition-colors">Instagram</a></li>
            </ul>
          </div>
        </div>
        <div className="mt-8 text-center text-sm text-gray-400">
          © 2023 Imortal Gaming. All rights reserved.
        </div>
      </div>
    </footer>
  )
}

