'use client'

import Image from 'next/image'
import { useState } from 'react'
import { X } from 'lucide-react'

interface Game {
  id: number
  title: string
  image: string
  url: string
}

export default function GameCard({ game }: { game: Game }) {
  const [isPlaying, setIsPlaying] = useState(false)

  const startGame = () => {
    setIsPlaying(true)
  }

  const closeGame = () => {
    setIsPlaying(false)
  }

  return (
    <div className="relative">
      {!isPlaying ? (
        <div
          className="group cursor-pointer"
          onClick={startGame}
        >
          <div className="relative overflow-hidden rounded-lg shadow-lg transition-transform duration-300 group-hover:scale-105">
            <Image
              src={game.image}
              alt={game.title}
              width={400}
              height={300}
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-1">{game.title}</h3>
              <p className="text-sm">Click to play</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
          <div className="relative w-full h-full max-w-4xl max-h-[80vh]">
            <button
              onClick={closeGame}
              className="absolute top-4 right-4 text-white hover:text-gray-300 z-10"
            >
              <X size={24} />
            </button>
            <iframe
              src={game.url}
              className="w-full h-full"
              allowFullScreen
            ></iframe>
          </div>
        </div>
      )}
    </div>
  )
}

