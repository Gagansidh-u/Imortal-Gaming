import Link from 'next/link'
import { Search } from 'lucide-react'
import Wallet from '@/components/Wallet'
import { useAuth } from '@/contexts/auth-context'

export default function Header() {
  const { user, logout } = useAuth()

  return (
    <header className="bg-gray-900 border-b border-gray-800">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="text-3xl font-bold text-purple-500">Imortal</Link>
          <nav>
            <ul className="flex space-x-6">
              <li><Link href="/" className="hover:text-purple-400 transition-colors">Home</Link></li>
              <li><Link href="/games" className="hover:text-purple-400 transition-colors">Games</Link></li>
            </ul>
          </nav>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search games..."
                className="bg-gray-800 text-white rounded-full py-2 px-4 pr-10 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <Search className="absolute right-3 top-2.5 text-gray-400" size={20} />
            </div>

            <Wallet />

            {user ? (
              <div className="relative">
                <button onClick={logout} className="text-white hover:text-purple-400 transition-colors">Logout</button>
              </div>
            ) : (
              <div className="flex space-x-2">
                <Link href="/login" className="text-white hover:text-purple-400 transition-colors">Login</Link>
                <Link href="/signup" className="text-white hover:text-purple-400 transition-colors">Signup</Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

