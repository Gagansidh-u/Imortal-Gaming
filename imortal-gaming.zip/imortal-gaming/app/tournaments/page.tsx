'use client'

import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/auth-context'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { calculatePrizeDistribution } from '@/utils/tournament'

interface Tournament {
  id: number
  name: string
  entryFee: number
  prize: number
  players: number
  startTime: string
  participants: { userId: string; username: string; score: number }[]
}

export default function TournamentsPage() {
  const { user, updateCoins } = useAuth()
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [registeredTournaments, setRegisteredTournaments] = useState<number[]>([])

  useEffect(() => {
    fetchTournaments()
  }, [])

  const fetchTournaments = async () => {
    const response = await fetch('/api/tournaments')
    if (response.ok) {
      const data = await response.json()
      setTournaments(data.tournaments)
    }
  }

  const registerForTournament = async (tournamentId: number, entryFee: number) => {
    if (!user) {
      // Redirect to login or show login modal
      return
    }

    if (user.coins < entryFee) {
      alert("Not enough coins to enter the tournament!")
      return
    }

    const response = await fetch(`/api/tournaments/${tournamentId}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id }),
    })

    if (response.ok) {
      setRegisteredTournaments([...registeredTournaments, tournamentId])
      await updateCoins(-entryFee)
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Tournaments</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tournaments.map((tournament) => (
          <Card key={tournament.id} className="bg-gray-800 text-white">
            <CardHeader>
              <CardTitle>{tournament.name}</CardTitle>
              <CardDescription className="text-gray-300">Entry Fee: {tournament.entryFee} coins</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Prize: {tournament.prize} coins</p>
              <p>Players: {tournament.players}</p>
              <p>Starts: {new Date(tournament.startTime).toLocaleString()}</p>
            </CardContent>
            <CardFooter>
              <Button
                onClick={() => registerForTournament(tournament.id, tournament.entryFee)}
                disabled={registeredTournaments.includes(tournament.id)}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                {registeredTournaments.includes(tournament.id) ? 'Registered' : 'Register'}
              </Button>
            </CardFooter>
            {tournament.participants.length > 0 && (
              <CardContent>
                <h3 className="text-xl font-bold mb-2">Leaderboard</h3>
                <ul>
                  {tournament.participants
                    .sort((a, b) => b.score - a.score)
                    .slice(0, 10)
                    .map((participant, index) => (
                      <li key={participant.userId} className="flex justify-between items-center mb-1">
                        <span>{index + 1}. {participant.username}</span>
                        <span>{participant.score}</span>
                      </li>
                    ))}
                </ul>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  )
}

