'use client'

import { useState, useEffect } from 'react'
import { useAuth } from '@/contexts/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { calculatePrizeDistribution } from '@/utils/tournament'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface Tournament {
  id: number
  name: string
  entryFee: number
  prize: number
  players: number
  startTime: string
  participants: { userId: string; username: string; score: number }[]
}

export default function AdminPanel() {
  const { user, login } = useAuth()
  const [tournaments, setTournaments] = useState<Tournament[]>([])
  const [newTournament, setNewTournament] = useState({
    name: '',
    entryFee: 0,
    prize: 0,
    players: 0,
    startTime: ''
  })
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [loginError, setLoginError] = useState('')

  useEffect(() => {
    if (isLoggedIn) {
      fetchTournaments()
    }
  }, [isLoggedIn])

  const fetchTournaments = async () => {
    const response = await fetch('/api/admin/tournaments')
    if (response.ok) {
      const data = await response.json()
      setTournaments(data.tournaments)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewTournament(prev => ({ ...prev, [name]: value }))
  }

  const createTournament = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch('/api/admin/tournaments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newTournament)
    })
    if (response.ok) {
      fetchTournaments()
      setNewTournament({
        name: '',
        entryFee: 0,
        prize: 0,
        players: 0,
        startTime: ''
      })
    }
  }

  const removeTournament = async (id: number) => {
    const response = await fetch(`/api/admin/tournaments/${id}`, {
      method: 'DELETE'
    })
    if (response.ok) {
      fetchTournaments()
    }
  }

  const endTournament = async (tournament: Tournament) => {
    const prizeDistribution = calculatePrizeDistribution(tournament.prize, tournament.participants.length)
    const sortedParticipants = tournament.participants.sort((a, b) => b.score - a.score)

    const winnings = sortedParticipants.map((participant, index) => ({
      userId: participant.userId,
      amount: prizeDistribution[index] || 0
    }))

    const response = await fetch(`/api/admin/tournaments/${tournament.id}/end`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ winnings })
    })

    if (response.ok) {
      fetchTournaments()
    }
  }

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)
    const email = formData.get('email') as string
    const password = formData.get('password') as string

    try {
      await login(email, password)
      if (email === 'Imortal.io' && password === 'Gagan@123') {
        setIsLoggedIn(true)
        setLoginError('')
      } else {
        setLoginError('Invalid credentials')
      }
    } catch (error) {
      setLoginError('Login failed')
    }
  }

  if (!isLoggedIn) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-md mx-auto">
          <CardHeader>
            <CardTitle>Admin Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input name="email" type="text" placeholder="Admin ID" required />
              <Input name="password" type="password" placeholder="Password" required />
              <Button type="submit" className="w-full">Login</Button>
            </form>
            {loginError && (
              <Alert variant="destructive" className="mt-4">
                <AlertDescription>{loginError}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-8">Admin Panel</h1>
      
      <Card className="mb-8 bg-gray-800 text-white">
        <CardHeader>
          <CardTitle>Create New Tournament</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={createTournament} className="space-y-4">
            <Input
              name="name"
              placeholder="Tournament Name"
              value={newTournament.name}
              onChange={handleInputChange}
              required
              className="bg-gray-700 text-white"
            />
            <Input
              name="entryFee"
              type="number"
              placeholder="Entry Fee"
              value={newTournament.entryFee}
              onChange={handleInputChange}
              required
              className="bg-gray-700 text-white"
            />
            <Input
              name="prize"
              type="number"
              placeholder="Prize"
              value={newTournament.prize}
              onChange={handleInputChange}
              required
              className="bg-gray-700 text-white"
            />
            <Input
              name="players"
              type="number"
              placeholder="Number of Players"
              value={newTournament.players}
              onChange={handleInputChange}
              required
              className="bg-gray-700 text-white"
            />
            <Input
              name="startTime"
              type="datetime-local"
              placeholder="Start Time"
              value={newTournament.startTime}
              onChange={handleInputChange}
              required
              className="bg-gray-700 text-white"
            />
            <Button type="submit" className="bg-purple-600 hover:bg-purple-700 text-white">Create Tournament</Button>
          </form>
        </CardContent>
      </Card>

      <h2 className="text-2xl font-bold mb-4">Existing Tournaments</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tournaments.map((tournament) => (
          <Card key={tournament.id} className="bg-gray-800 text-white">
            <CardHeader>
              <CardTitle>{tournament.name}</CardTitle>
              <CardDescription className="text-gray-300">Entry Fee: {tournament.entryFee} coins</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Prize: {tournament.prize} coins</p>
              <p>Players: {tournament.players}</p>
              <p>Starts: {new Date(tournament.startTime).toLocaleString()}</p>
              <p>Participants: {tournament.participants.length}</p>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button onClick={() => removeTournament(tournament.id)} variant="destructive">
                Remove Tournament
              </Button>
              <Button onClick={() => endTournament(tournament)} className="bg-green-600 hover:bg-green-700 text-white">
                End Tournament
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Card className="mt-8 bg-gray-800 text-white">
        <CardHeader>
          <CardTitle>Website Monetization</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4">
            <div>
              <label htmlFor="adNetwork" className="block mb-2">Ad Network</label>
              <select id="adNetwork" className="w-full bg-gray-700 text-white rounded p-2">
                <option value="google">Google AdSense</option>
                <option value="facebook">Facebook Audience Network</option>
                <option value="amazon">Amazon Associates</option>
              </select>
            </div>
            <Input
              name="adCode"
              placeholder="Ad Code"
              className="bg-gray-700 text-white"
            />
            <Button type="submit" className="bg-purple-600 hover:bg-purple-700 text-white">Add Ad</Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}

