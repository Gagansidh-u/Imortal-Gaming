'use client'

import { useState } from 'react'
import GameCard from '@/components/GameCard'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const categories = [
  'All',
  'Action',
  'Adventure',
  'Arcade',
  'Puzzle & Logic',
  'Sports & Racing',
  'Strategy',
]

const games = [
  {
    id: 1,
    title: 'Subway Surfers',
    image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/12a0ed7c6bc09b73d6558c6f69ed7f5f.png',
    url: 'https://poki.com/en/g/subway-surfers',
    category: 'Action',
    coinsReward: 50,
  },
  { id: 2, title: 'Stickman Hook', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/85911b7e3a50ab30e1eaa2f8a1b0d5c3.png', url: 'https://poki.com/en/g/stickman-hook', category: 'Action', coinsReward: 75 },
  { id: 3, title: 'Vex 7', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/d2708e8aa31440e2a4a5c7f38d727f36.png', url: 'https://poki.com/en/g/vex-7', category: 'Puzzle & Logic', coinsReward: 60 },
  { id: 4, title: 'Rocket Soccer Derby', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/e43611793ed7a3f1a33cb9c0a5c86c89.png', url: 'https://poki.com/en/g/rocket-soccer-derby', category: 'Sports & Racing', coinsReward: 80 },
  { id: 5, title: 'Tomb of the Mask', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/5b0abd3c0c8d5b9f0a8348bd23b1bb0b.png', url: 'https://poki.com/en/g/tomb-of-the-mask', category: 'Puzzle & Logic', coinsReward: 55 },
  { id: 6, title: 'Stickman Climb 2', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/7f5649f1e2977b8bf9638c33e7aa8988.png', url: 'https://poki.com/en/g/stickman-climb-2', category: 'Adventure', coinsReward: 70 },
  { id: 7, title: 'Geometry Dash', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/9411a3e8d7c53c239cd5324b81b7a329.png', url: 'https://poki.com/en/g/geometry-dash-online', category: 'Arcade', coinsReward: 90 },
  { id: 8, title: 'Crazy Cars', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/cb29cb34-185d-4a0d-8598-f9fc2d6cfe4f.jpg', url: 'https://poki.com/en/g/crazy-cars', category: 'Arcade', coinsReward: 65 },
  { id: 9, title: 'Scrap Metal 3', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/8b8f1e7f-6f7c-4ce7-9d5d-74f4172a3b21.jpg', url: 'https://poki.com/en/g/scrap-metal-3', category: 'Puzzle & Logic', coinsReward: 50 },
  { id: 10, title: 'Fireboy and Watergirl', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/e7ce4e78-24c9-4e7a-b74f-87681a8087c1.png', url: 'https://poki.com/en/g/fireboy-and-watergirl-1', category: 'Puzzle & Logic', coinsReward: 85 },
  { id: 11, title: 'Blumgi Ball', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/d4c03349-8aec-4a60-b1e2-6a6d3fb6f8c1.jpg', url: 'https://poki.com/en/g/blumgi-ball', category: 'Sports & Racing', coinsReward: 70 },
  { id: 12, title: 'Stickman Climb', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/d6f3cd54-e448-4748-b44a-6e9e3b7ab70e.jpg', url: 'https://poki.com/en/g/stickman-climb', category: 'Adventure', coinsReward: 60 },
  { id: 13, title: 'Vex 6', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/9f0b1f98-8de1-4f51-8bbb-7e0e0db13e7e.png', url: 'https://poki.com/en/g/vex-6', category: 'Puzzle & Logic', coinsReward: 75 },
  { id: 14, title: 'Merge Cyber Racers', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/4ba2d10c-a685-4cfe-b81a-0924efc0e5f0.png', url: 'https://poki.com/en/g/merge-cyber-racers', category: 'Sports & Racing', coinsReward: 95 },
  { id: 15, title: 'Tall Man Run', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/cf570c41-0f19-4f87-b4d5-e1c9f9f08d8c.png', url: 'https://poki.com/en/g/tall-man-run', category: 'Adventure', coinsReward: 80 },
  { id: 16, title: 'Stickman Bridge Constructor', image: 'https://img.poki.com/cdn-cgi/image/quality=78,width=600,height=600,fit=cover,f=auto/9a9e2a9f-3e81-4e4f-8e2c-a5c4c6071e9a.png', url: 'https://poki.com/en/g/stickman-bridge-constructor', category: 'Strategy', coinsReward: 65 },
]

export default function GamesPage() {
  const [selectedCategory, setSelectedCategory] = useState('All')

  const filteredGames = games.filter(
    (game) => selectedCategory === 'All' || game.category === selectedCategory
  )

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="All" className="w-full">
          <TabsList className="w-full justify-start overflow-x-auto">
            {categories.map((category) => (
              <TabsTrigger
                key={category}
                value={category}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </TabsTrigger>
            ))}
          </TabsList>
          <TabsContent value={selectedCategory} className="mt-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
              {filteredGames.map((game) => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

