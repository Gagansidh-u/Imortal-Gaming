export function calculatePrizeDistribution(totalPrize: number, playerCount: number): number[] {
  const distribution = [];
  
  if (playerCount >= 1) distribution.push(totalPrize * 0.15); // 1st place: 15%
  if (playerCount >= 2) distribution.push(totalPrize * 0.10); // 2nd place: 10%
  if (playerCount >= 3) distribution.push(totalPrize * 0.05); // 3rd place: 5%
  
  const remainingPrize = totalPrize * 0.70; // 70% for remaining players
  
  if (playerCount > 3) {
    const fourthToTwentiethCount = Math.min(17, playerCount - 3);
    const fourthToTwentiethPrize = remainingPrize * (30 / 70);
    for (let i = 0; i < fourthToTwentiethCount; i++) {
      distribution.push(fourthToTwentiethPrize / fourthToTwentiethCount);
    }
  }
  
  if (playerCount > 20) {
    const twentyFirstToSixtiethCount = Math.min(40, playerCount - 20);
    const twentyFirstToSixtiethPrize = remainingPrize * (40 / 70);
    for (let i = 0; i < twentyFirstToSixtiethCount; i++) {
      distribution.push(twentyFirstToSixtiethPrize / twentyFirstToSixtiethCount);
    }
  }
  
  return distribution;
}

