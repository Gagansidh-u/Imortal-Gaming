'use client'

import { createContext, useContext, useEffect, useState } from 'react'

interface User {
  id: string
  email: string
  username: string
  avatar?: string
  coins: number
  progress: {
    [gameId: string]: {
      lastPlayed: string
      score: number
      achievements: string[]
    }
  }
}

interface MultiplayerGame {
  id: string
  players: string[]
  status: 'waiting' | 'in-progress' | 'completed'
}

interface AuthContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<void>
  signup: (email: string, username: string, password: string) => Promise<void>
  logout: () => Promise<void>
  updateProfile: (data: Partial<User>) => Promise<void>
  createMultiplayerGame: (gameId: string) => Promise<string>
  joinMultiplayerGame: (gameId: string) => Promise<void>
  updateCoins: (amount: number) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkAuth()
  }, [])

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/check')
      if (response.ok) {
        const data = await response.json()
        setUser(data.user)
      }
    } finally {
      setLoading(false)
    }
  }

  const login = async (email: string, password: string) => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    })
    
    if (!response.ok) {
      throw new Error('Login failed')
    }
    
    const data = await response.json()
    setUser(data.user)
  }

  const signup = async (email: string, username: string, password: string) => {
    const response = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, username, password }),
    })
    
    if (!response.ok) {
      throw new Error('Signup failed')
    }
    
    const data = await response.json()
    setUser(data.user)
  }

  const logout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' })
    setUser(null)
  }

  const updateProfile = async (data: Partial<User>) => {
    const response = await fetch('/api/user/profile', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
    
    if (!response.ok) {
      throw new Error('Profile update failed')
    }
    
    const updatedUser = await response.json()
    setUser(updatedUser)
  }

  const createMultiplayerGame = async (gameId: string): Promise<string> => {
    if (!user) throw new Error('User not authenticated')

    const response = await fetch('/api/multiplayer/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gameId, userId: user.id }),
    })

    if (!response.ok) {
      throw new Error('Failed to create multiplayer game')
    }

    const data = await response.json()
    return data.gameId
  }

  const joinMultiplayerGame = async (gameId: string): Promise<void> => {
    if (!user) throw new Error('User not authenticated')

    const response = await fetch('/api/multiplayer/join', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gameId, userId: user.id }),
    })

    if (!response.ok) {
      throw new Error('Failed to join multiplayer game')
    }
  }

  const updateCoins = async (amount: number): Promise<void> => {
    if (!user) throw new Error('User not authenticated')

    const response = await fetch('/api/user/update-coins', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId: user.id, amount }),
    })

    if (!response.ok) {
      throw new Error('Failed to update coins')
    }

    const updatedUser = await response.json()
    setUser(updatedUser)
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading, 
      login, 
      signup, 
      logout, 
      updateProfile,
      createMultiplayerGame,
      joinMultiplayerGame,
      updateCoins
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

