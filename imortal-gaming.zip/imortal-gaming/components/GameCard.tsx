'use client'

import { useState } from 'react'
import Image from 'next/image'
import { X, Coins, Heart, Play } from 'lucide-react'
import { useAuth } from '@/contexts/auth-context'
import { Button } from '@/components/ui/button'
import { Leaderboard } from './Leaderboard'

interface Game {
  id: number
  title: string
  image: string
  url: string
  category: string
  coinsReward: number
}

export default function GameCard({ game }: { game: Game }) {
  const { user, updateProfile, updateCoins } = useAuth()
  const [isPlaying, setIsPlaying] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)
  const [players, setPlayers] = useState<{ id: string; username: string; score: number }[]>([])

  const startGame = async () => {
    if (!user) {
      // Redirect to login or show login modal
      return
    }
    setIsPlaying(true)
    setPlayers([{ id: user.id, username: user.username, score: 0 }])
    
    // Update last played timestamp
    const gameProgress = user.progress[game.id] || {}
    await updateProfile({
      progress: {
        ...user.progress,
        [game.id]: {
          ...gameProgress,
          lastPlayed: new Date().toISOString(),
        },
      },
    })
  }

  const closeGame = async () => {
    setIsPlaying(false)
    
    // Award coins for playing
    if (user) {
      await updateCoins(game.coinsReward)
    }
  }

  const updatePlayerScore = (playerId: string, newScore: number) => {
    setPlayers(prevPlayers => 
      prevPlayers.map(player => 
        player.id === playerId ? { ...player, score: newScore } : player
      )
    )
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
  }

  return (
    <div className="relative">
      {!isPlaying ? (
        <div className="group">
          <div className="relative overflow-hidden rounded-lg shadow-lg transition-transform duration-300 group-hover:scale-105">
            <Image
              src={game.image}
              alt={game.title}
              width={400}
              height={300}
              className="w-full h-48 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <div className="absolute top-2 right-2">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:text-purple-400"
                onClick={toggleFavorite}
              >
                <Heart
                  className={`w-6 h-6 ${isFavorite ? 'fill-current' : ''}`}
                />
              </Button>
            </div>
            <div className="absolute bottom-2 left-2">
              <Button
                variant="ghost"
                size="icon"
                className="bg-purple-600 hover:bg-purple-700 text-white rounded-full"
                onClick={startGame}
              >
                <Play className="w-6 h-6" />
              </Button>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
              <h3 className="text-lg font-semibold mb-1">{game.title}</h3>
              <div className="flex items-center justify-between">
                <span className="text-sm">{game.category}</span>
                <div className="flex items-center text-yellow-500">
                  <Coins className="w-4 h-4 mr-1" />
                  <span>{game.coinsReward}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-75">
          <div className="relative w-full h-full max-w-4xl max-h-[80vh]">
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 text-white hover:text-gray-300 z-10"
              onClick={closeGame}
            >
              <X size={24} />
            </Button>
            <iframe
              src={game.url}
              className="w-full h-full rounded-lg"
              allowFullScreen
            />
            <div className="absolute bottom-4 left-4 right-4">
              <Leaderboard players={players} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

