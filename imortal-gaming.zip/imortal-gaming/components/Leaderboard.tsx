import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface Player {
  id: string;
  username: string;
  score: number;
}

interface LeaderboardProps {
  players: Player[];
}

export function Leaderboard({ players }: LeaderboardProps) {
  const sortedPlayers = [...players].sort((a, b) => b.score - a.score);

  return (
    <div className="bg-gray-800 p-4 rounded-lg">
      <h2 className="text-2xl font-bold mb-4 text-white">Leaderboard</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="text-white">Rank</TableHead>
            <TableHead className="text-white">Player</TableHead>
            <TableHead className="text-white">Score</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedPlayers.map((player, index) => (
            <TableRow key={player.id}>
              <TableCell className="text-white">{index + 1}</TableCell>
              <TableCell className="text-white">{player.username}</TableCell>
              <TableCell className="text-white">{player.score}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

