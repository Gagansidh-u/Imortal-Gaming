'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Search, Menu } from 'lucide-react'
import { useAuth } from '@/contexts/auth-context'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

const categories = [
  { name: 'Action', href: '/games/action' },
  { name: 'Adventure', href: '/games/adventure' },
  { name: 'Arcade', href: '/games/arcade' },
  { name: 'Puzzle & Logic', href: '/games/puzzle' },
  { name: 'Sports & Racing', href: '/games/sports' },
  { name: 'Strategy', href: '/games/strategy' },
]

export default function Header() {
  const { user, logout } = useAuth()

  return (
    <header className="bg-gray-900 border-b border-gray-800">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <Link href="/" className="text-3xl font-bold text-purple-500">
              Imortal
            </Link>
            <nav className="hidden md:block">
              <ul className="flex space-x-6">
                {categories.map((category) => (
                  <li key={category.name}>
                    <Link
                      href={category.href}
                      className="hover:text-purple-400 transition-colors"
                    >
                      {category.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search games..."
                className="bg-gray-800 text-white rounded-full py-2 px-4 pr-10 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
              <Search className="absolute right-3 top-2.5 text-gray-400" size={20} />
            </div>

            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger>
                  <div className="flex items-center space-x-2">
                    <Image
                      src={user.avatar || '/placeholder.svg?height=40&width=40'}
                      alt={user.username}
                      width={40}
                      height={40}
                      className="rounded-full"
                    />
                    <span className="hidden md:inline">{user.username}</span>
                  </div>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>
                    <Link href="/profile">Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={logout}>
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex space-x-2">
                <Link
                  href="/login"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-full"
                >
                  Login
                </Link>
                <Link
                  href="/signup"
                  className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 rounded-full"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

