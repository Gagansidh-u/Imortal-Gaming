'use client'

import { useAuth } from '@/contexts/auth-context'
import { Coins } from 'lucide-react'

export default function Wallet() {
  const { user } = useAuth()

  if (!user) return null

  return (
    <div className="flex items-center bg-purple-700 rounded-full px-4 py-2 text-white">
      <Coins className="w-5 h-5 mr-2" />
      <span className="font-bold">{user.coins}</span>
    </div>
  )
}

