'use client'

import { useState } from 'react'
import Image from 'next/image'
import { useAuth } from '@/contexts/auth-context'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Coins } from 'lucide-react'

export default function UserProfile() {
  const { user, updateProfile } = useAuth()
  const [editing, setEditing] = useState(false)
  const [avatar, setAvatar] = useState(user?.avatar)
  const [username, setUsername] = useState(user?.username)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!user) return

    await updateProfile({
      username,
      avatar,
    })
    setEditing(false)
  }

  if (!user) return null

  return (
    <div className="bg-gray-900 rounded-lg p-6 max-w-md mx-auto">
      <div className="flex items-center space-x-4 mb-6">
        <div className="relative">
          <Image
            src={user.avatar || '/placeholder.svg?height=100&width=100'}
            alt={user.username}
            width={100}
            height={100}
            className="rounded-full"
          />
          {editing && (
            <Input
              type="text"
              placeholder="Avatar URL"
              value={avatar}
              onChange={(e) => setAvatar(e.target.value)}
              className="mt-2"
            />
          )}
        </div>
        <div>
          <h2 className="text-2xl font-bold">{user.username}</h2>
          <div className="flex items-center text-yellow-500">
            <Coins className="w-5 h-5 mr-2" />
            <span>{user.coins} coins</span>
          </div>
        </div>
      </div>

      {editing ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
            />
          </div>
          <div className="flex space-x-2">
            <Button type="submit">Save Changes</Button>
            <Button variant="outline" onClick={() => setEditing(false)}>
              Cancel
            </Button>
          </div>
        </form>
      ) : (
        <Button onClick={() => setEditing(true)}>Edit Profile</Button>
      )}
    </div>
  )
}

